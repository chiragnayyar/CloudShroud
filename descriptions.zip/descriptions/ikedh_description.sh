#!/bin/bash

echo ""
echo "Your partner may have given you a form which includes the parameters to use to build a VPN with their company. Look for the 'diffie-helman group', 'group', or 'dh group' field under the phase 1 section (phase 1 is also referred to as 'isakmp' or 'ike' by some companies). If you do not see anything like this, you may try just going with '2' for now as this is a very common dh group number that is used." | fold -w 80
echo ""