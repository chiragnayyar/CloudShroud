#!/bin/bash
echo ""
echo "Although IKEv2 is the newer version, IKEv1 is still probably the most commonly used. This is the version also used by AWS VPN endpoints. Unless the partner you're trying to establish the VPN with asks for otherwise, you probably want to go with IKEv1. If you can find more on the specific differences here \http://www.differencebetween.net/technology/protocols-formats/difference-between-ikev1-and-ikev2/" | fold -w 80
echo ""